import main_func as mf
from main_func import my_function

print("Normal Call")
in1, in2 = 5, 2
out1, out2 = mf.my_function(in1, in2)
print(f"Summation:  {out1}")
print(f"Difference: {out2}")
print()

print("Different Inputs")
in1, in2 = 45, 89
out1, out2 = my_function(in1, in2)
print(f"Summation:  {out1}")
print(f"Difference: {out2}")
print()

print("Input Positions Change")
in1, in2 = 5, 2
out1, out2 = mf.my_function(in2, in1)
print(f"Summation:  {out1}")
print(f"Difference: {out2}")
print()

print("Output Positions Change")
in1, in2 = 5, 2
out2, out1 = mf.my_function(in1, in2)
print(f"Summation:  {out1}")
print(f"Difference: {out2}")
