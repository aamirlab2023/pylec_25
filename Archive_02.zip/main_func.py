def my_function(var1, var2):
    """This function computes the summation and difference of two input numbers."""
    y = var1 + var2
    z = var1 - var2
    return y, z
