#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul  6 13:16:06 2024

@author: aamir
"""

celcius = 0
increment = 5
stop = 25
while celcius <= stop:
    fahrenheit = (9/5)*celcius + 32
    print(f'{celcius:<9.2f}{fahrenheit:.2f}')
    celcius += increment
print("Program terminated successfully.")