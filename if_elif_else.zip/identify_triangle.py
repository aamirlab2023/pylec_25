#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Programmer: Aamir Alaud Din, PhD
# Program: identify_triangle.py
# Date: 2021.10.20

# Objective(s):
#   To identify the shape of a triangle.

triangle_sides = []

a = float(input("Enter the lenght of 1st side: "))
triangle_sides.append(a)
b = float(input("Enter the lenght of 2nd side: "))
triangle_sides.append(b)
c = float(input("Enter the lenght of 3rd side: "))
triangle_sides.append(c)

long_index = triangle_sides.index(max(triangle_sides))
long = max(triangle_sides)
del triangle_sides[long_index]

if long**2 == triangle_sides[0]**2 + triangle_sides[1]**2:
	print()
	print("Result:")
	print("=======")
	print("The triangle is a right triangle.")
	print("Length of hypotenuous = %.4f units" % long)
	print("Length of side 1 = %.4f units" % triangle_sides[0])
	print("Length of side 2 = %.4f units" % triangle_sides[1])
elif a == b and b == c:
	print()
	print("Result:")
	print("=======")
	print("The triangle is an equilateral triangle.")
	print("Length of side 1 = %.4f units" % a)
	print("Length of side 2 = %.4f units" % b)
	print("Length of side 3 = %.4f units" % c)
elif a == b or b == c or c == a:
	print()
	print("Result:")
	print("=======")
	print("The triangle is an isosceles triangle.")
	print("Length of side 1 = %.4f units" % a)
	print("Length of side 2 = %.4f units" % b)
	print("Length of side 3 = %.4f units" % c)
else:
	print()
	print("Result:")
	print("=======")
	print("The triangle is an irregular triangle.")
	print("Length of side 1 = %.4f units" % a)
	print("Length of side 2 = %.4f units" % b)
	print("Length of side 3 = %.4f units" % c)
