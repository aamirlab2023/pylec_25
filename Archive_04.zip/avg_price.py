def avg_price(price_data):

    total_price = 0
    for counter, price in enumerate(price_data):
        print(counter, price)
        total_price += price

    avg = total_price/(counter + 1)

    return avg

prices = [4000, 5000, 6000]
average_value = avg_price(prices)
print(f"The average price of office chair is PKR {average_value:.2f}")

prices = [4000, 4000, 4000, 4000]
average_value = avg_price(prices)
print(f"The average price of office chair is PKR {average_value:.2f}")
