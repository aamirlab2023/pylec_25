#!/usr/bin/env python3
"""
    generalize.py - This program prompts the user to input the required table
    and the starting and stoping points in the table. The program, then,
    displays the required table from the given starting point through the
    stopping point on the standard output display device.

    Copyright (C) 2024 Aamir Alaud Din

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

table = int(input("Enter the required table: "))
start = int(input("Enter the starting point of the table: "))
stop = int(input("Enter the stopping point of the table: "))
for counter in range(start, stop + 1):
    print(f'{table:d} x {counter:d} = {table*counter:d}')
