#!/usr/bin/env python3
"""
    determinant.py - This program computes and displays the determinant of the
    specified matrix on the standard output display.

    Copyright (C) 2024 Aamir Alaud Din

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""


import numpy as np


matrix = np.array([[-2, 7, 0, 6, -2],
                   [1, -1, 3, 2, 2],
                   [3, 4, 0, 5, 3],
                   [2, 5, -4, -2, 2],
                   [0, 3, -1, 1, -4]])

print(f'Determinant of given matrix is {np.linalg.det(matrix):.2f}')
