name_head = "Student Name:"
id_head = "Student ID:"
cgpa_head = "Student CGPA:"
name = "Aamir Alaud Din"
n_id = 781120
cgpa = 3.87
print(f"{name_head:<14s}{name}")
print(f"{id_head:<14s}{n_id}")
print(f"{cgpa_head:<14s}{cgpa:.2f}")
print()
print(f"{name_head:<14s}{name}\n{id_head:<14s}{n_id}\n{cgpa_head:<14s}{cgpa:.2f}")
print()
statement = f"{name_head:<14s}{name}\n{id_head:<14s}{n_id}\n{cgpa_head:<14s}{cgpa:.2f}"
print(statement)
