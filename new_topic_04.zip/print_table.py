sr1, sr2, sr3 = 1, 2, 3
mass1, mass2, mass3 = 2.579, 25.1245, 89.2
vel1, vel2, vel3 = 120.35, 56.25, 100.9
ke1, ke2, ke3 = 18677.2760, 39747.7441, 454064.126
print("Sr. No.    Mass       Velocity    Kinetic Energy")
print("=======    =======    ========    ==============")
print(f"{sr1:<7d}    {mass1:7.4f}    {vel1:8.4f}    {ke1:.4f}")
print(f"{sr2:<7d}    {mass2:7.4f}    {vel2:8.4f}    {ke2:.4f}")
print(f"{sr3:<7d}    {mass3:7.4f}    {vel3:8.4f}    {ke3:.4f}")
