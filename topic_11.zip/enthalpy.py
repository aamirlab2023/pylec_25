#!/usr/bin/env python3

a = 1.35E-5
b = -3.25E-3
c = 6.91
m = 8000.0
t1 = 0.00
temp_list = [75, 79, 93, 89, 58, 13, 53, 22, 92, 5]
print("Temperature    Specific Heat    Enthalpy")
print("===========    =============    ==========")
for tf in temp_list:
    cp = a*tf**2 + b*tf + c
    print(f'{tf:^11.2f}    {cp:^13.4f}    {m*cp*tf:^8.4E}')




