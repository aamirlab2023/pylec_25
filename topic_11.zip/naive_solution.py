#!/usr/bin/env python3

# define variables and parameters
a = 1.35E-5
b = -3.25E-3
c = 6.91
m = 8000.0
t1 = 0.00

print("Temperature    Specific Heat    Specific Enthalpy")
print("===========    =============    =================")
# computation at T = 10
t = 75
delta = t - t1
cp = a*t**2 + b*t + c
h = m*cp*delta
print(f'{t:<11d}    {cp:<13.4E}    {h:<17.4E}')


# computation at T = 20
t = 79
delta = t - t1
cp = a*t**2 + b*t + c
h = m*cp*delta
print(f'{t:<11d}    {cp:<13.4E}    {h:<17.4E}')


# computation at T = 30
t = 93
delta = t - t1
cp = a*t**2 + b*t + c
h = m*cp*delta
print(f'{t:<11d}    {cp:<13.4E}    {h:<17.4E}')


# computation at T = 40
t = 89
delta = t - t1
cp = a*t**2 + b*t + c
h = m*cp*delta
print(f'{t:<11d}    {cp:<13.4E}    {h:<17.4E}')


# computation at T = 50
t = 58
delta = t - t1
cp = a*t**2 + b*t + c
h = m*cp*delta
print(f'{t:<11d}    {cp:<13.4E}    {h:<17.4E}')


# computation at T = 60
t = 13
delta = t - t1
cp = a*t**2 + b*t + c
h = m*cp*delta
print(f'{t:<11d}    {cp:<13.4E}    {h:<17.4E}')


# computation at T = 70
t = 53
delta = t - t1
cp = a*t**2 + b*t + c
h = m*cp*delta
print(f'{t:<11d}    {cp:<13.4E}    {h:<17.4E}')


# computation at T = 80
t = 22
delta = t - t1
cp = a*t**2 + b*t + c
h = m*cp*delta
print(f'{t:<11d}    {cp:<13.4E}    {h:<17.4E}')


# computation at T = 90
t = 92
delta = t - t1
cp = a*t**2 + b*t + c
h = m*cp*delta
print(f'{t:<11d}    {cp:<13.4E}    {h:<17.4E}')


# computation at T = 100
t = 5
delta = t - t1
cp = a*t**2 + b*t + c
h = m*cp*delta
print(f'{t:<11d}    {cp:<13.4E}    {h:<17.4E}')
