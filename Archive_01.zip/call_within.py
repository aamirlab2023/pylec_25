def my_function(var1, var2):
    """This function computes the summation and difference of two input numbers."""
    y = var1 + var2
    z = var1 - var2
    return y, z

in1, in2 = 5, 2
out1, out2 = my_function(in1, in2)
print(f"Summation:  {out1}")
print(f"Difference: {out2}")
