initial_velocity = 2.5 # m/s
acceleration = 0.9 # m/s**2
time = 5 # min
time = 5*60 # s

# compute distance
distance = initial_velocity*time + 0.5*acceleration*time**2 # km

# show output on output display device
print(distance)
